document.getElementById('sign').addEventListener('click',
function() {
document.querySelector('.bg-modal').style.display = 'flex';
});

document.querySelector('.close').addEventListener('clcik',
function() {
document.querySelector('.bg-modal').style.display = 'none';
});